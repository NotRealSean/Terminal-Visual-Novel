This is a small project about make game with only console(terminal/command prompt) control

Download link(I'm stupid and don't know how to publish game on github) : https://drive.google.com/drive/folders/1rT2ZEjRkOe1OtI-tTtGd1wmYhQUXpb5-?usp=share_link

This project made by NotRealSean

Control:
Menu
You'll see "Key command -=>" at the bottom
Type something and hit "Enter" on your keyboard

Story
just hit "Enter" or "Space bar" to continue reading

Common problem:
If you can't open game/crash while open game
Check if your computer has .net framework or not
if not download it here(at least 6.0) : https://dotnet.microsoft.com/en-us/download

Have any problem?
Contract me at...
Discord : NotRealSean#4001 / https://discord.gg/mcqkhyeYaG
Twitter : @Seankungzaza1
